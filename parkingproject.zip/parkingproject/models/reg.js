const mongoose=require('mongoose')

let regSchema=mongoose.Schema({
    us:String,
    pass:String
})
module.exports=mongoose.model('reg',regSchema)

