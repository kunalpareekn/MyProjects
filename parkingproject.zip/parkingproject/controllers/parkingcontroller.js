const parking = require('../models/parking')
const Parking=require('../models/parking')



exports.parkingdetails=async(req,res)=>{
    const record=await parking.find()
    const parkingin=await parking.count({status:'IN'})

    res.render('parking.ejs',{record,parkingin})
}
exports.addform=(req,res)=>{
    res.render('addform.ejs',{message:''})
}
exports.add=async(req,res)=>{
    const{vno,vtype}=req.body
    const record=await new parking({vno:vno,vtype:vtype})
    record.save()
    // console.log(record)
    res.render('addform.ejs',{message:'Successfully Inserted'})


}
exports.update=async(req,res)=>{
    const id=req.params.id
    const record=await Parking.findById(id)
    let vout=new Date()
    let spendtime=((vout-record.vintime)/(1000*60*60))
    // console.log(spendtime)
    let amount=0
    if(record.vtype=='2w')
    {
        amount=spendtime*20
    }
    else if(record.vtype=='3w')
    {
        amount=spendtime*50
    }
    else if(record.vtype=='4w')
    {
        amount=spendtime*80
    }
    else if(record.vtype=='lw')
    {
        amount=spendtime*100

    }
    else if(record.vtype=='hw')
    {
        amount=spendtime*150
    }
    else
    {
        amount=spendtime*200
    }

   
    await Parking.findByIdAndUpdate(id,{vouttime:vout,amount:Math.round(amount),status:'OUT'})
    res.redirect('/parking')
}
exports.print=async(req,res)=>{
    const id=req.params.id
    const record=await Parking.findById(id)
    res.render('printinvoice.ejs',{record})
}
