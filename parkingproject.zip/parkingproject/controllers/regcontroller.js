const Reg=require('../models/reg')
const bcrypt=require('bcrypt')




exports.login=(req,res)=>{
    res.render('login.ejs',{message:''})
}
exports.loginform=async(req,res)=>{
    const{us,pass}=req.body
    const record=await Reg.findOne({us:us})
    if(record!==null)
    {
        const passCompare=await bcrypt.compare(pass,record.pass)
        if(passCompare){
            res.redirect('/parking')
        }
        else{
            res.render('login.ejs',{message:'Wrong credentails'})


        }

       
    }
    else
    {
        res.render('login.ejs',{message:'Wrong credentails'})
    }

        


}
exports.regis=(req,res)=>{
    res.render('reg.ejs',{message:''})
}
exports.regform=async(req,res)=>{
    const{us,pass}=req.body
let convertedpass=await bcrypt.hash(pass,10)
// console.log(convertedpass)
const record=new Reg({us:us,pass:convertedpass})
record.save()
res.render('reg.ejs',{message:'Successfully user has been created'})

}





