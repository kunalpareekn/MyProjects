const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const parkingc=require('../controllers/parkingcontroller')



router.get('/',regc.login)
router.post('/',regc.loginform)
router.get('/reg',regc.regis)
router.post('/reg',regc.regform)
router.get('/parking',parkingc.parkingdetails)
router.get('/addNew',parkingc.addform)
router.post('/addNew',parkingc.add)
router.get('/parkingupdate/:id',parkingc.update)
router.get('/parkingprint/:id',parkingc.print)


module.exports=router