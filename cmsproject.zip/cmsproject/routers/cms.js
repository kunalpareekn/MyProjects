const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const reg = require('../models/reg')
const multer=require('multer')
let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/userprofile')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,

    limits:{fileSize:1024*1024*4}
}
)
function handlerole(req,res,next){
    if(req.session.role!=='free'){
        next()
    }
    else{
        res.send("you dont't have Subscription to see the your Contact Details ")
    }
}

function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }
    else{
        res.redirect('/') 
    }
}


router.get('/',regc.loginpage)

router.get('/reg',regc.regpage)
router.post('/reg',regc.register)
router.post('/',regc.login)
router.get('/userprofile',handlelogin,regc.userprofile)
router.get('/logout',regc.logout)
router.get('/forgot',regc.forgotpage)
router.post('/forgot',regc.forgotlinksend)
router.get('/changepassword/:email',regc.passresetform)
router.post('/changepassword/:email',regc.resetpasschange)
router.get('/profile',regc.updateprofilepage)
router.post('/profile',upload.single('img'),regc.updateprofile)
router.get('/contactdetail/:id',handlerole,regc.contactdetail)
router.get('/passwordreset',regc.passreset)
router.post('/passwordreset',regc.passwordresetform)
















module.exports=router