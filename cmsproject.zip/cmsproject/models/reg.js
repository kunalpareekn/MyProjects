const mongoose=require('mongoose')

const regSchema=mongoose.Schema({
    email:String,
    pass:String,
    firstName:String,
    lastName:String,
    mobile:Number,
    desc:String,
    role:{type:String,default:'free'},
    img:{type:String,default:'maleAvatar.png'},
    createDate:{type:Date,default:new Date()},
    status:{type:String,default:'suspended'}


})







module.exports=mongoose.model('reg',regSchema)