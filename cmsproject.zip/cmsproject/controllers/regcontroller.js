const Reg = require('../models/reg')
const nodemailer = require('nodemailer')
const multer=require('multer')



exports.loginpage = (req, res) => {
    res.render('login.ejs', { message: '' })
}
exports.regpage = (req, res) => {
    res.render('reg.ejs', { message: '' })
}
exports.register = async (req, res) => {
    const { email, pass } = req.body
    const emailcheck = await Reg.findOne({ email: email })


    try {
        if (emailcheck == null) {
            const record = new Reg({ email: email, pass: pass })
            record.save()
            res.render('reg.ejs', { message: 'successfully created' })
        }
        else {
            res.render('reg.ejs', { message: "Email is Already Registered" })
        }
    }
    catch (error) {
        res.render('reg.ejs', { message: error.message })


    }

}
exports.login = async (req, res) => {
    const { email, pass } = req.body
    const emailcheck = await Reg.findOne({ email: email })
    if (emailcheck !== null) {
        if (emailcheck.pass == pass) {
            if (emailcheck.status == 'suspended' & emailcheck.email !== 'admin@gmail.com') {
                res.render('login.ejs', { message: 'your account is suspended.cordinate with Admin' })

            }
            else {
                req.session.isAuth = true
                req.session.username = email
                req.session.role=emailcheck.role
                if (emailcheck.email == 'admin@gmail.com') {
                    res.redirect('/admin/dashboard')
                }
                else {
                    res.redirect('/userprofile')
                }
            }

        }
        else {
            res.render('login.ejs', { message: 'Wrong password' })
        }
    }
    else {
        res.render('login.ejs', { message: 'Wrong credentials' })
    }



}

exports.userprofile =async (req, res) => {

    const loginname = req.session.username
 
    let test=['maleAvatar.png']
    const record=await Reg.find({img:{$nin:test}})

    // console.log(record)
    
    res.render('userprofile.ejs',{ loginname,record })
}
exports.logout = (req, res) => {
    req.session.destroy()
    res.redirect('/')
}
exports.forgotpage = (req, res) => {
    res.render('forgotform.ejs', { message: '' })
}
exports.forgotlinksend = async (req, res) => {
    const { email } = req.body
    let testAccount = await nodemailer.createTestAccount();

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
            user: 'rahulshr8949@gmail.com', // generated ethereal user
            pass: 'mjcypijsqmkqfsbg', // generated ethereal password
        },
    });
    console.log('coonected to SMTP')
    let info = await transporter.sendMail({
        from: 'rahulshr8949@gmail.com', // sender address
        to: email, // list of receivers
        subject: 'Password reset link:cms', // Subject line
        text: 'Please click below link to Reset the password', // plain text body
        html: `<a href='http://localhost:5000/changepassword/${email}'>Click to Reset</a>`, // html body

    });
    console.log('sent mail')
    res.render('forgotform.ejs', { message: 'Password reset link has been sent your registered Email id' })
}

exports.passresetform = (req, res) => {
    res.render('passresetform.ejs', { message: '' })
}
exports.resetpasschange = async (req, res) => {
    const email = req.params.email
    const { pass } = req.body
    const record = await Reg.findOne({ email: email })
    const id = record.id
    await Reg.findByIdAndUpdate(id, { pass: pass })
    res.render('passchangemessage.ejs', { message: 'Successfully Password changed plz try with new Password' })

}

exports.admindashboard = (req, res) => {
    const username = req.session.username


    res.render('admin/dashboard.ejs', { username })
}
exports.adminusers = async (req, res) => {
    const username = req.session.username
    const record = await Reg.find()

    res.render('admin/users.ejs', { username, record,message:''})
}
exports.userstatusupdate=async(req,res)=>{
    const id=req.params.id
    const records=await Reg.findById(id)
    let newStatus=null
    if(records.status=='suspended'){
        newStatus='active'
    }
    else
    {
        newStatus='suspended'
    }
    await Reg.findByIdAndUpdate(id,{status:newStatus})
    const username = req.session.username
    const record = await Reg.find()
    res.render('admin/users.ejs',{ username,record,message:'Successfully Updated'})
    
}
exports.updateprofilepage=async(req,res)=>{
    
    const loginname = req.session.username
    const record=await Reg.findOne({email:loginname})

    res.render('profileformpage.ejs',{loginname,record,message:' '})
}
exports.updateprofile=async(req,res)=>{

    console.log(req.body)
    const{fname,lname,mobile,desc}=req.body
    const loginname = req.session.username
    const user=await Reg.findOne({email:loginname})
    const id=user.id
    if(req.file){
        const filename=req.file.filename
        await Reg.findByIdAndUpdate(id,{firstName:fname,lastName:lname,mobile:mobile,desc:desc,img:filename})
    }
    else{
        await Reg.findByIdAndUpdate(id,{firstName:fname,lastName:lname,mobile:mobile,desc:desc})
    }
    
    const record=await Reg.findOne({email:loginname})
    res.render('profileformpage.ejs',{loginname,record,message:'Successfully profile'})


}
exports.userdelete=async(req,res)=>{
    const id=req.params.id
await Reg.findByIdAndDelete(id)
const username = req.session.username
const record = await Reg.find()
res.render('admin/users.ejs', { username, record,message:'Successfully Deleted'})


}

exports.contactdetail=async(req,res)=>{
    const id=req.params.id
    const loginname = req.session.username
    const record=await Reg.findById(id)
    

    res.render('contactdetail.ejs',{loginname,record})
}
exports.roleupdate=async(req,res)=>{
    const id=req.params.id
    const records=await Reg.findById(id)
    let newrole=null
if(records.role=='free'){
newrole='subscribed'
}
else
{
    newrole='free'
}
await Reg.findByIdAndUpdate(id,{role:newrole})
const username = req.session.username
const record= await Reg.find()
res.render('admin/users.ejs', { username,record,message:'update'})
}
exports.passreset=(req,res)=>{
    const loginname = req.session.username
    
    res.render('passreset.ejs',{loginname})
}
exports.passwordresetform=async(req,res)=>{

    const{cpass,npass}=req.body
    const loginname=req.session.username
    // console.log(loginname)
    const record=await Reg.findOne({email:loginname})
    // console.log(record)
    const id=record.id
    let newpass=null
    // console.log(id)
    if(record.pass==cpass){
         newpass=npass
        //  console.log(newpass)
    }
    else{
        res.render('passreset.ejs',{loginname,message:'please enter current password correctly'})
    }
    await Reg.findByIdAndUpdate(id,{pass:newpass})
    res.render('passreset.ejs',{loginname,message:'Password Reset Successfully'})


}